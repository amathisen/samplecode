<?php
  
// Spelling functions

// Function to produce vowel replacements in a string
function parseVowelReplacement($textString,$currentPlace=-1) {

  //$vowelArray = array("a","A","e","E","i","I","o","O","u","U");
  $vowelArray = array("a","e","i","o","u");
  // Uncomment the following line to include 'y' in the list of vowels
  // $vowelArray = array("a","A","e","E","i","I","o","O","u","U","y","Y");

  if(!$textString)
    return array($textString);
  
  $allCombos = array();

  for ($x = 0; $x < strlen($textString); $x++) {
  
    $currentLetter = strtolower(substr($textString,$x,1));
    
    if ($x > $currentPlace && in_array($currentLetter,$vowelArray)) {
    
      foreach ($vowelArray as $thisVowel) {
      
        if ($thisVowel != $currentLetter) {
          
          $tmpString = substr_replace($textString,$thisVowel,$x,1);
          
          if (!in_array($tmpString,$allCombos)) {
          
            $allCombos[] = $tmpString;
            $allCombos = array_merge($allCombos,parseVowelReplacement($tmpString,$x));
          
          }
          
        }
        
      }
      
    }
    
  }
  
  return array_unique($allCombos);
  
}
// Function to produce combinations of removals of consecutive letters in a string
function parseConsecutiveLetters($textString) {

  if(!$textString)
    return array($textString);
    
  $allCombos = array();

  for ($x = 0; $x < strlen($textString) - 1; $x++) {
  
    if (substr($textString,$x,1) == substr($textString,$x+1,1)) {
  
      $tmpString = substr($textString,0,$x+1) . substr($textString,$x+2);
      $allCombos[] = $tmpString;
      $allCombos = array_merge($allCombos,parseConsecutiveLetters($tmpString));
    
    }
  
  }
  
  return array_unique($allCombos);
  
}

// Function to produce casing combinations for a string
function getCasingCombinations($textString){

  if(!$textString)
    return array($textString);

  $allCases = array();

  foreach(getCasingCombinations(substr($textString, 1)) as $thisCase){
  
    $lower = strtolower($textString[0]);
    $allCases[] = $lower . $thisCase;

    $upper = strtoupper($textString[0]);
    
    if($upper !== $lower)
      $allCases[] = $upper . $thisCase;

    }
    
  return $allCases;
    
}

function checkSpelling($textString) {

  // Populate array with the list of words
  $dictionaryWords = file("assets/english.dict", FILE_IGNORE_NEW_LINES);
  $suggestion = "";

  $textString = trim($textString);
  
  if (preg_match('/[^A-Za-z]/', $textString))
    return "<hr /><br />'Text String' must contain only letters.";
    
  // Check if the word is already spelled correctly
  // If not, do work
  if (in_array($textString,$dictionaryWords))
    $suggestion = $textString . " (You spelled the word correctly. Yay!)";
  else {
    
    // Grab all combos
    $allCasesCombos = getCasingCombinations($textString);
    $allConsecutiveCombos =  parseConsecutiveLetters($textString);
    $allVowelCombos = parseVowelReplacement($textString);

    // Check if we have a match
    $allCombos = array_merge($allCasesCombos,$allConsecutiveCombos,$allVowelCombos);
    $testArray = array_intersect($dictionaryWords,$allCombos);
    
    if (is_array($testArray) && count($testArray))
      $suggestion = current($testArray);

    if ($suggestion == "") {
    
      foreach ($allCasesCombos as $thisCase) {
    
        $allCasesCombos = array_merge($allCasesCombos,parseConsecutiveLetters($thisCase));
        $testArray = array_intersect($dictionaryWords,$allCasesCombos);
        
        if (is_array($testArray) && count($testArray))
          $suggestion = current($testArray);
        else {
        
          $allCasesCombos = array_merge($allCasesCombos,parseVowelReplacement($thisCase));
          $testArray = array_intersect($dictionaryWords,$allCasesCombos);
        
          if (is_array($testArray) && count($testArray))
            $suggestion = current($testArray);
    
        }
        
        if ($suggestion != "")
          break;
        
      }
    

    }

    if ($suggestion == "") {
    
      foreach ($allConsecutiveCombos as $thisCase) {
    
        $allConsecutiveCombos = array_merge($allConsecutiveCombos,getCasingCombinations($thisCase));
        $testArray = array_intersect($dictionaryWords,$allConsecutiveCombos);
        
        if (is_array($testArray) && count($testArray))
          $suggestion = current($testArray);
        else {
        
          $allConsecutiveCombos = array_merge($allConsecutiveCombos,parseVowelReplacement($thisCase));
          $testArray = array_intersect($dictionaryWords,$allConsecutiveCombos);
        
          if (is_array($testArray) && count($testArray))
            $suggestion = current($testArray);
    
        }
        
        if ($suggestion != "")
          break;
        
      }
    

    }

    if ($suggestion == "") {
    
      foreach ($allVowelCombos as $thisCase) {
    
        $allVowelCombos = array_merge($allVowelCombos,getCasingCombinations($thisCase));
        $testArray = array_intersect($dictionaryWords,$allVowelCombos);
        
        if (is_array($testArray) && count($testArray))
          $suggestion = current($testArray);
        else {
        
          $allVowelCombos = array_merge($allVowelCombos,parseConsecutiveLetters($thisCase));
          $testArray = array_intersect($dictionaryWords,$allVowelCombos);
        
          if (is_array($testArray) && count($testArray))
            $suggestion = current($testArray);
    
        }
        
        if ($suggestion != "")
          break;
        
      }
    

    }
    
    /*
    $allCombos = array_merge($allCasesCombos,$allConsecutiveCombos,$allVowelCombos);
    $testArray = array_intersect($dictionaryWords,$allCombos);
    
    if (is_array($testArray) && count($testArray))
      */
  }

  // No match found
  if ($suggestion == "")
    $suggestion = "NO SUGGESTION";

  $spellingOutput = "<hr /><br /><table>";
  $spellingOutput .= "<tr><td>Input:</td><td>" . $textString . "</td></tr>";
  $spellingOutput .= "<tr><td>Suggestion:</td><td>" . $suggestion . "</td></tr>";
  $spellingOutput .= "</table>";

  return $spellingOutput;

}


?>