<?php

// Include file holding spell check functions
include_once("modules/spellingFunctions.php");

// Did we receive a text string to check?
if ($_POST && $_POST["textString"])
  $suggestionValue = checkSpelling($_POST["textString"]);
else
  $suggestionValue = "";

?>

<html>

  <head>
  
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  
    <script src="js/formValidation.js"></script>

    <title>Aaron Mathisen - EnergySavvy Spellcheck Coding Problem</title>
    
  </head>
  
  <body>
  
    <h2>EnergySavvy Spellcheck Coding Problem</h2>
    
    <span style="font-size: 10px;">By <a href = "mailto:nelk81@gmail.com">Aaron Mathisen</a></span>
  
    <p>Enter a text string in the text box below to return a spelling suggestion for an English word based on rules described on the <a href = "http://dl.dropboxusercontent.com/u/342881/spellcheck.htm" target="_blank">coding problem</a> page.</p>
  
    <p>Dictionary source file (relative to root of this project): 'assets/english.dict'.</p>

    <p>
  
      <form name="spellCheckForm" id="spellCheckForm" action="index.php" method="post" onsubmit="return validateForm()">
      
        Text String&nbsp;&nbsp;&nbsp;<input type="text" name="textString" id="textString">&nbsp;&nbsp;&nbsp;<input type="submit" value="Check Spelling">
      
      </form>
  
    </p>

    <?php echo $suggestionValue; ?>

  </body>
  
</html>