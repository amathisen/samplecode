<!-- Function to validate form input -->

function validateForm() {

  var textString = document.getElementById("textString");
  var textStringValue = textString.value.trim();
  var letters = /^[A-Za-z]+$/;

  // We didn't receive a value
  if (textStringValue.length == 0) {
  
    alert("Please enter a word to check.");
    textString.focus();
    textString.select();
    return false;
  
  }

  // We received illegal characters (we only want letters)
  if (!textStringValue.match(letters)) {
  
    alert("'Text String' must contain only letters.");
    textString.focus();
    textString.select();
    return false;
  
  }
 
  return true;

}