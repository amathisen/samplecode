All of the files contained in this directory were created by Aaron Mathisen.

core_geo.php - Functions used to look up IP ranges and return formatted responses for the purposes of rendering heat maps
module_deviceManagement - Functions to control creation/modification of device objects
module_tagManagement - Functions to control tag objects
