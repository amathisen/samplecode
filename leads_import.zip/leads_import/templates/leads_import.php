<?php
/**
 * Marketing Lead Tracking Import.
 *
 * @url         $URL: https://svn.siliconmechanics.com/web/trunk/trogdor_html/marketing/templates/lead_import.php $
 * @date        $Date: 2014-12-10 08:41:15 -0700 (Wed, 10 Dec 2014) $
 * @version     $Revision: 10415 $
 * @author      $Author: aaron.mathisen $
 * @copyright   Silicon Mechanics
 *
 * @package     SiMech
 * @subpackage  Trogdor
 *
/**/
    $Page_Title = 'Marketing Leads Import';
    $Extra_Headers[] = '<script type="text/javascript" src="/js/' . svn_rev . '/scal.js"></script>';
    $Extra_Headers[] = '<script type="text/javascript" src="/js/' . svn_rev . '/widgets.js"></script>';

    include 'templates_edit/header.php';

?>

<script>
	function validate_delete() {
		var delete_checkbox = document.getElementById("delete_existing_leads");
		var leads_file = document.getElementById("leads_file");

		if(!leads_file.value) {
			alert("Please select a file to upload.");
			return false;
		}

		if (delete_checkbox.checked) {
			return confirm("Are you sure you want to DELETE ALL existing leads?");
		}
		
		return true;
	}

</script>

<table id="marketing_leads" border="0" cellspacing="1" cellpadding="2" class="borders" width="90%" sortable="true" align="center">
	<caption>Marketing Leads Import</caption>

	<?php if($return_message && $return_message != "") { ?> <tr><td class="commands1"><?php echo $return_message; ?></td></tr> <?php } ?>

	<tr>
		<td class="commands1">
			<form class="form" name="form" method="post" action="leads_import.php" enctype="multipart/form-data" onSubmit="return validate_delete()">
				Select Leads CVS File <input type="file" name="leads_file" id="leads_file">
				<input type="checkbox" name="delete_existing_leads" id="delete_existing_leads" checked title="Check this box to have all existing leads deleted.">Delete existing leads
    			<input type="submit" value="Import" name="submit">
			</form>
		</td>
	</tr>
		
</table>

<?php

include "templates_edit/footer.php"
?>
