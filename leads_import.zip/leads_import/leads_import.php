<?php
/**
 * view/use the Marketing reports area
 *
 * @url         $URL: https://svn.siliconmechanics.com/web/trunk/trogdor_html/marketing/leads_import.php $
 * @date        $Date: 2014-12-10 17:21:54 -0700 (Wed, 10 Dec 2014) $
 * @version     $Revision: 10409 $
 * @author      $Author: aaron.mathisen $
 * @copyright   Silicon Mechanics
 *
 * @package     SiMech
 * @subpackage  Trogdor
 *
/**/

// Basic page settings - editor name, includes, company name
$Editor_Name = 'Marketing Leads Import';

// Load the initialization routines
require_once dirname($_SERVER['DOCUMENT_ROOT'])."/shared_code/includes/init_edit.php";

if(!$Editor_User->permission('import_leads','marketing'))
	permission_denied();

// Message to display to user. This may be an error, or a count of successful imports.
$return_message = "";

if(isset($_FILES['leads_file']) && file_exists($_FILES['leads_file']['tmp_name'])) {

	$filename = $_FILES['leads_file']['name'];
	$ext = pathinfo($filename, PATHINFO_EXTENSION);
	
	// Attempted to upload non-csv file
	if(strtolower($ext) != "csv") {
		$return_message  = "ERROR. File must be of type 'CSV'.";
	} else {

		// Populate array from uploaded file
		$leads_array = fopen($_FILES['leads_file']['tmp_name'],"r");
	
		GLOBAL $db;
		$db->start_transaction();
		$leads_count = 0;

		// Clear existing leads if the user checked the box to do so
		if($_POST['delete_existing_leads'] && $_POST['delete_existing_leads'] == "on") {
			$db->query('DELETE FROM Marketing_Leads');
			$return_message = "Existing leads deleted.<br>";
		}

		// Loop over file one line at a time
		while(!feof($leads_array)) {
		
			$data = fgetcsv($leads_array);

			// If the first element is 'first name', assume the line contains headers and skip. Skip data empty (usually last line)
			if(strtolower($data[0]) != "first name" && $data) {

				$leads_count++;
			
				$hotlead = $data[9];
				switch ($hotlead) {
					case 'Yes':
						$hotness = 3;
						break;
					case 'No':
						$hotness = 1;
						break;
					case 'NA':
						$hotness = 2;
						break;
					default:
						$hotness = 0;
				}

				$oldDate = $data[8];
				$newDate = date_format(date_create_from_format('m/d/Y', $oldDate), 'Y-m-d');
			
				// Insert new lead
				$db->query('INSERT INTO obfuscated_table_name (field1,field2,field3,field4,field5,field6,field7,field8,field8,field10,field11,field12,field13)
                        	VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
						$data[0],$data[1],$data[2],$data[3],$data[4],$data[5],$data[6],$data[7],$newDate,$hotness,(bool)$data[10],(bool)$data[11],(bool)$data[12],$data[13]
				);

			}
		} 
	
		fclose($leads_array);
		$db->commit();
		$return_message .= "Successfully imported " . $leads_count . " leads.";
	}
}

// Toolbar(s) and initial active tab setting

if($Editor_User->permission('view_leads','marketing')) {
	$Toolbar->add_tab(
		array('id'     => 'tab_lead_tracking_report',
			'href'   => 'marketing.php?page=leads',
			'title'  => 'Lead Tracking Report',
			'name'   => 'Lead Tracking Report',
			)
	);
}

	$Toolbar->add_tab(array('id'     => 'tab_lead_tracking_import',
		'href'   => 'leads_import.php',
		'title'  => 'Lead Tracking Import',
		'name'   => 'Lead Tracking Import',
	)
);


if (isset($_REQUEST['page']))
    $page_prefs['page'] = $_REQUEST['page'];
if (!preg_match('/^(?:leads|details)/i', $page_prefs['page']))
    unset($page_prefs['page']);


// page and page pref setting and template call
$Toolbar->active_tab('tab_lead_tracking_import');
require "templates/leads_import.php";
$page_prefs['page'] = '';
exit;
