<?php
/**
 *
 * @url         $URL: xxxx
 * @date        $Date: 2015-03-15 17:55:03 -0700$
 * @version     $Revision: 10206 $
 * @author      $Author: amathisen $
 * @copyright   Silicon Mechanics
 *
 * @package     SiMech
 *
**/

interface TaxEngine {
    public function getTaxRate($Customer, $Address, $ItemList);
	public function getTaxCodes($Customer, $Address);
    public function getTax($Customer, $Address, $ItemList);
    public function postTax($Customer, $Address, $ItemList);
    public function validateAddress($Address);
    public function ping();
    public function getAdminUrl();
    public function getServiceMessage();
}
