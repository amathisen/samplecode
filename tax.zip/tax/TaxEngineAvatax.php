<?php
/**
 *
 * @url         $URL: https://svn.siliconmechanics.com/web/trunk/shared_code/classes/TaxEngineAvatax.php $
 * @date        $Date: 2015-03-31 10:04:03 -0700 (Tue, 31 Mar 2015) $
 * @version     $Revision: 11022 $
 * @author      $Author: aaron.mathisen $
 * @copyright   Silicon Mechanics
 *
 * @package     SiMech
 *
/**/

// In here cause maint scripts don't use the config dirs...
// Also, not using the other default, as it seems to change at times?
// kormoc - I know I wrote that last comment, but WTF?
global $DEFAULT_ORIGIN_ADDRESS;
$DEFAULT_ORIGIN_ADDRESS = new stdClass();
$DEFAULT_ORIGIN_ADDRESS->street1    = '22029 23rd Dr SE';
$DEFAULT_ORIGIN_ADDRESS->street2    = '';
$DEFAULT_ORIGIN_ADDRESS->street3    = '';
$DEFAULT_ORIGIN_ADDRESS->city       = 'Bothell';
$DEFAULT_ORIGIN_ADDRESS->state      = 'WA';
$DEFAULT_ORIGIN_ADDRESS->country    = 'US';
$DEFAULT_ORIGIN_ADDRESS->zip        = '98021';

class TaxEngineAvatax implements TaxEngine {
    private        $service_url                = 'https://avatax.avalara.net';
    private        $service_url_test           = 'https://development.avalara.net';
    private        $admin_url                  = 'https://admin-avatax.avalara.net';
    private        $admin_url_test             = 'https://admin-development.avalara.net';
    private        $account                    = 'xxxx';
    private        $account_test               = 'yyyy';
    private        $license                    = 'llll';
    private        $license_test               = 'mmmm';
    private        $company_code               = 'SIMECH';
    private        $client                     = 'Silicon Mechanics - PHP-Java bridge';
/* @var            bool                          If warnings fail the tax request */
    private        $strict                     = TRUE;

    private        $tax_info_cache             = NULL;
    private        $tax_info_cache_signature   = NULL;

    private        $service_messages           = array();
	private        $tax_results;
	protected 	   $kill_switch				   = false;

    public function __construct() {

    	require_once(dirname($_SERVER['DOCUMENT_ROOT']) . '/third_party/AvaTax/AvaTax4PHP/AvaTax.php');
    	require_once(dirname($_SERVER['DOCUMENT_ROOT']) . '/third_party/AvaTax/Credentials.php');

    }

    public function __destruct() {
    // Avatax's examples show this, but it seems to break things...
        //@java_reset();
    }

/**
 *  @param       object      $Customer       A Customer object of the customer to charge tax to
 *  @param       object      $Address        A Address object of the address to charge tax to
 *  @param       object      $ItemList       A ItemList object of the items to charge tax to
 *  @return      float                      The tax rate as a float (.05 is 5%)
**/
    public function getTaxRate($Customer, $Address, $ItemList) {
		if($this->kill_switch)
			return 0.00;

		if(!isset($this->tax_results))
        	$this->getTaxInfo($Customer, $Address, $ItemList);

		if(!isset($this->tax_results) || $this->tax_results->getResultCode() != SeverityLevel::$Success)
			return false;

		$totalRate = 0;
		foreach($this->tax_results->getTaxLines()[0]->getTaxDetails() as $tmp)
			$totalRate += $tmp->getRate();

        return $totalRate;
    }

/**
 *  @param       object      $Customer       A Customer object of the customer to charge tax to
 *  @param       object      $Address        A Address object of the address to charge tax to
 *  @param       object      $ItemList       A ItemList object of the items to charge tax to
 *  @return      float                       The tax to charge
**/
    public function getTax($Customer, $Address, $ItemList) {

		if($this->kill_switch)
			return 0.00;

        $TaxInfo = $this->getTaxInfo($Customer, $Address, $ItemList);

        if (!is_null($TaxInfo) && isset($TaxInfo['Tax']))
            return $TaxInfo['Tax'];

        return NULL;
    }

/**
 *  @param      object      $Address        A Address object of the address to validate
 *  @param		bool		$skip_validate	Set to 'true' (default) to use previous results (if exists. else make new call) from $this->tax_results
 *  										Set to 'false' to make an independent call to Avatax to validate address
 *  @return     bool                        valid or not
**/
    public function validateAddress($Address, $skip_validate=true) {

		if($this->kill_switch)
			return true;

		if ($skip_validate == true || !isset($this->tax_results)) {

			if(!isset($this->tax_results) || $this->tax_results->getResultCode() != SeverityLevel::$Success)
				return false;
		 
			return true;
			
		}

		if (dev_domain)
			$client = new AddressServiceSoap('Development');
		else
			$client = new AddressServiceSoap('Production');

        try {
        	
 			$address = new Address_AvaTax();
            $address->setLine1      ($Address->street1);
            $address->setLine2      ($Address->street2);
            $address->setLine3      ($Address->street3);
            $address->setCity       ($Address->city);
            $address->setRegion     ($Address->state);
            if(isset($Address->zipcode))
            	$address->setPostalCode ($Address->zipcode);
            elseif (isset($Address->zip))
				$address->setPostalCode ($Address->zip);

            $textCase = TextCase::$Mixed;
            $coordinates = 1;

            $request = new ValidateRequest($address, ($textCase ? $textCase : TextCase::$Default), $coordinates);
            $result = $client->Validate($request);

            if(!isset($result) || $result->getResultCode() != SeverityLevel::$Success)
            	return FALSE;
            else
            	return TRUE;
        }
       catch(SoapFault $exception) {
            assert('FALSE; //'.$exception->faultstring);
        }
        return FALSE;
    }

/**
 *  @return     bool                Do we get back info from Avatax?
**/
    public function ping() {
		if($this->kill_switch)
			return true;

		if (dev_domain)
			$client = new AddressServiceSoap('Development');
		else
			$client = new AddressServiceSoap('Production');

        try {
			$result = $client->ping("");
			if($result->getResultCode() != SeverityLevel::$Success)
				return false;
			else
				return true;
        }
        catch (SoapFault $exception) {
            assert('FALSE; //'.$exception->faultstring);
        }
        return false;
    }

/**
 *  @return     string          the sevice url to use on this domain
**/
    private function getServiceUrl() {
        if (dev_domain)
            return $this->service_url_test;
        return $this->service_url;
    }

/**
 *  @return     string          the admin url to use on this domain
**/
    public function getAdminUrl() {
        if (dev_domain)
            return $this->admin_url_test;
        return $this->admin_url;
    }

/**
 *  @return     string          the account string to use on this domain
**/
    private function getAccount() {
        if (dev_domain)
            return $this->account_test;
        return $this->account;
    }

/**
 *  @return     string          the license to use on this domain
**/
    private function getLicense() {
        if (dev_domain)
            return $this->license_test;
        return $this->license;
    }

/**
 *  @return     string          the first service message or FALSE or no message
**/
    public function getServiceMessage() {
        if (is_valid_array($this->service_messages))
            return $this->getUserFriendlyMessage($this->service_messages[0]['summary']);
        return FALSE;
    }

/**
 *  @return     string          a user friendly message
**/
    private function getUserFriendlyMessage($SystemMessage) {
        switch ($SystemMessage) {
            case 'CustomerVendorCode is required.':         return 'Customer Account is required';
            default:                                        return $SystemMessage;
        }
    }

/**
 *  @param      object      $Customer       A Customer object of the customer to charge tax to
 *  @param      object      $Address        A Address object of the address to charge tax to
 *  @param      object      $ItemList       A ItemList object of the items to charge tax to
 *  @param      bool        $CommitTax      Are we going to commit this transaction or not
 *  @return     array                       A array with all the tax info results or NULL on failure
**/
    private function getTaxInfo($Customer, $Address, $ItemList, $CommitTax = FALSE) {

		if($this->kill_switch)
			return null;
        if (    !assert('is_valid_array($ItemList->items)')
             || !assert('get_class($Address)  == "Address"')
             || !assert('get_class($Customer) == "Customer"') )
            return NULL;

        try {

        	if (dev_domain)
        		$client = new TaxServiceSoap('Development');
        	else
        		$client = new TaxServiceSoap('Production');
        	
        	$request= new GetTaxRequest();
        	
        	$origin = new Address_AvaTax();
        	global $DEFAULT_ORIGIN_ADDRESS;
        	$origin->setLine1($DEFAULT_ORIGIN_ADDRESS->street1);
        	$origin->setLine2($DEFAULT_ORIGIN_ADDRESS->street2);
        	$origin->setCity($DEFAULT_ORIGIN_ADDRESS->city);
        	$origin->setRegion($DEFAULT_ORIGIN_ADDRESS->state);
        	$origin->setPostalCode($DEFAULT_ORIGIN_ADDRESS->zip);
        	$request->setOriginAddress($origin);

        	$destination=  new Address_AvaTax();
        	$destination->setLine1($Address->street1);
        	$destination->setLine2($Address->street2);
        	$destination->setCity($Address->city);
        	$destination->setRegion($Address->state);
        	$destination->setPostalCode($Address->zip);
        	$request->setDestinationAddress	($destination);
        	$request->setCompanyCode($this->company_code);
        	
        	if ($CommitTax)
        		$request->setDocType(DocumentType::$SalesInvoice);
        	else
        		$request->setDocType(DocumentType::$SalesOrder);

        	$dateTime=new DateTime();
        	$request->setDocCode($ItemList->type.'-'.$ItemList->id);
        	$request->setDocDate(date_format($dateTime,"Y-m-d"));
        	global $Editor_User;
        	global $User;
        	if($Editor_User->login) {
        		$request->setSalespersonCode($Editor_User->login);
        		// Avatax requires a customer code. If we don't have a customer, set to 'Unknown'
        		if(!empty($Customer->id))
        			$request->setCustomerCode($Customer->id);
        		else
        			$request->setCustomerCode("Unknown");
        	}
        	if($User && $User->id) {
        		$request->setCustomerCode($User->id);
        	}
        	$request->setDetailLevel(DetailLevel::$Tax);
        	$request->setLocationCode("");

            $line_items = $this->getTaxLineItems($ItemList);

            // No tax if we don't have any items
			if ( count($line_items) == 0 || $Customer->tax_exempt)
				return array('Tax' => 0);

			if ($ItemList->shipping > 0) {
				$line = new Line();
				$line->setNo(count($line_items)+1);
				$line->setItemCode("SHIPPING");
				$line->setDescription("Shipping");
				$line->setTaxCode('Tax');
				$line->setQty(1.0);
				$line->setAmount(number_format($ItemList->shipping, 2, '.', ''));
				array_push($line_items,$line);
			}

			$request->setLines($line_items);

			$this->tax_results = $client->getTax($request);

			// We failed. Set error message to display to user
			if($this->tax_results->getResultCode() != SeverityLevel::$Success) {
				$error_messages = "";

				foreach($this->tax_results->getMessages() as $msg)
					$error_messages .= $msg->getSummary() . "<br>";

				$this->service_messages[0]['summary'] = $error_messages;
				return NULL;
			}

            $return['DocCode']          = $request->getDocCode();
            $return['DocID']            = $this->tax_results->getDocId();
            $return['DocDate']          = $this->tax_results->getDocDate();
            $return['DocDateEnglish']   = $this->tax_results->getDocDate();
            $return['Total']            = floatval($this->tax_results->getTotalAmount());
            $return['Tax']              = floatval($this->tax_results->getTotalTax());
            $return['Items']            = array();
            $return['TaxRates']         = array();

            $i = 0;
            foreach($this->tax_results->getTaxLines() as $ctl) {
                $return['Items'][$i] = array(
                                              'Number'        => intval($ctl->getNo()),
                                              'Tax'           => floatval($ctl->getTax()),
                                              'TaxCode'       => strval($ctl->getTaxCode()),
                                              'Rates'         => array()
                                             );
                $j = 0;
                foreach($ctl->getTaxDetails() as $ctd) {
                    $return['Items'][$i]['Rates'][$j] = array(
                                                               'Jurisdiction Type'     => strval($ctd->getJurisType()),
                                                               'Jurisdiction Name'     => strval($ctd->getJurisName()),
                                                               'Rate'                  => floatval($ctd->getRate()),
                                                               'Amount'                => floatval($ctd->getTax())
                                                              );
                    
                    if(!array_key_exists($i,$return['TaxRates']))
                    	$return['TaxRates'][$i] = 0;

                    $return['TaxRates'][$i] += $return['Items'][$i]['Rates'][$j]['Rate'];
                    $j++;
                }
            	$i++;
            }
            $return['TaxRates'] = array_unique($return['TaxRates']);
            assert('count($return["TaxRates"]) == 1;');
            $return['TaxRate'] = $return['TaxRates'][0];

            if ($return['TaxRate'] == 0 && $return['Tax'] > 0) {
                assert('FALSE; // Manual Tax Rate Calculating, this can be problematic.');
                $return['TaxRate'] = round($return['Tax'] / $return['Total'],4);
            }

            return $return;
        }
        catch (SoapFault $exception) {
            assert('FALSE; //'.$exception->faultstring);
        }
        return NULL;
    }

/**
 *  @param       object      $Customer      A Customer object of the customer to charge tax to
 *  @param       object      $Address       A Address object of the address to charge tax to
 *  @param       object      $ItemList      A ItemList object of the items to charge tax to
 *  @return      bool                       Success or not
**/
    public function postTax($Customer, $Address, $ItemList) {
    	// For Avatax, never post tax. Posting of tax is done via Quickbooks
    	return true;
    }

/**
 *  @param      object      $ItemList       a ItemList object
 *  @return     array                       an array of java objects
**/
    private function getTaxLineItems($ItemList) {
        $lines = array();
        $count =0;
        foreach ($ItemList->items AS $key => $Item) {
            if (     $Item->fields['status']  == 'Deleted'
                 ||  $Item->fields['status']  == 'Returned'
                 || !$Item->fields['taxable'])
                continue;

            $lines[] = $this->getTaxLineItem($count++, $Item->id, $Item->quantity, $Item->fields['saleprice'], $Item->fields['internal_name']);
        }
        return $lines;
    }

/**
 *  @param      int         $count          What line number are we
 *  @param      string      $item_code      SKU or ID of the item
 *  @param      int         $quantity       How many items are we selling?
 *  @param      int         $price          Sale Price per item
 *  @param      string      $description    The item description
 *  @return     object                      The java object of this line item
**/
    private function getTaxLineItem($count = NULL, $item_code = NULL, $quantity = 0, $price = 0, $description = '') {
    	if (is_null($count) || is_null($item_code) || $quantity == 0 || $price == 0 )
            return NULL;
        $line = new Line();
        $line->setNo($count);
        $line->setItemCode($item_code);
        $line->setDescription($description);
        $line->setTaxCode('Tax');
        $line->setQty(number_format($quantity, 1, '.', ''));
        $line->setAmount(number_format($price * $quantity, 2, '.', ''));
        $line->setCustomerUsageType("");
        return $line;
    }
    
	public function getTaxCodes($Customer, $Address) {
		/*
        global $db;
        $codes = $db->query_list_assoc('SELECT CityNo, CountyNo FROM Tax_TX_Address_Lookup WHERE CityName = \'Dallas\'');
        if(!is_valid_array($codes))
            return array();
        $stuffed = array();
        foreach($codes as $code)
            $stuffed[] = sprintf('%0d / %0d', $code['CityNo'], $code['CountyNo']);
        print_r($stuffed); exit;
        return $stuffed;
        */
		return array();
    }
}
