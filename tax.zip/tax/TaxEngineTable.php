<?php
/**
 *
 * @url         $URL: https://svn.siliconmechanics.com/web/trunk/shared_code/classes/TaxEngineTable.php $
 * @date        $Date: 2015-10-15 17:55:03 -0700 (Thu, 15 Oct 2015) $
 * @version     $Revision: 10206 $
 * @author      $Author: amathisen $
 * @copyright   Silicon Mechanics
 *
 * @package     SiMech
 *
**/

class TaxEngineTable implements TaxEngine {

    private $taxRates = array ( 'WA' => 0.089,
                                //'CA' => 0.0875,
                                //'MA' => 0.05
                              );

    public function getTaxRate($Customer, $Address, $ItemList) {
        if (isset($this->taxRates[$Address->state]) && !$Customer->tax_exempt)
            return $this->taxRates[$Address->state];
        return 0;
    }

    public function getTax($Customer, $Address, $ItemList) {
        if ($Customer->tax_exempt)
            return 0;
        $taxableTotal = 0;
        foreach ($ItemList->items AS $Item)
            if (    $Item->fields['taxable']
                 && $Item->fields['status']  != 'Returned'
                 && $Item->fields['status']  != 'Deleted' )
                $taxableTotal += ($Item->fields['saleprice'] * $Item->quantity);
        if ($taxableTotal > 0)
            $taxableTotal += $ItemList->shipping;
        return round($taxableTotal * $this->getTaxRate($Customer, $Address, $ItemList), 2);
    }

    public function postTax($Customer, $Address, $ItemList) {
        return TRUE;
    }

    public function validateAddress($Address) {
        return $Address->validate();
    }

    public function ping() {
        return TRUE;
    }

    public function getAdminUrl() {
        return '';
    }

    public function getServiceMessage() {
        return FALSE;
    }
}
